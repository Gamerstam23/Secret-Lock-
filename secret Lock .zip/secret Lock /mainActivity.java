package com.example.securemedia;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnPhotos = findViewById(R.id.btnPhotos);
        Button btnVideos = findViewById(R.id.btnVideos);
        Button btnApkFiles = findViewById(R.id.btnApkFiles);
        Button btnBrowser = findViewById(R.id.btnBrowser);

        btnPhotos.setOnClickListener(v -> securePhotos());
        btnVideos.setOnClickListener(v -> secureVideos());
        btnApkFiles.setOnClickListener(v -> secureApkFiles());
        btnBrowser.setOnClickListener(v -> openBrowser());
    }

    private void securePhotos() {
        createSecureDirectory("Photos");
    }

    private void secureVideos() {
        createSecureDirectory("Videos");
    }

    private void secureApkFiles() {
        createSecureDirectory("APKs");
    }

    private void createSecureDirectory(String type) {
        File secureDir = new File(getExternalFilesDir(null), "SecureMedia/" + type);
        if (!secureDir.exists()) {
            secureDir.mkdirs();
            // Notify user about the creation of the directory
            // You can also move files into this directory here
        }
    }

    private void openBrowser() {
        Intent intent = new Intent(this, BrowserActivity.class);
        startActivity(intent);
    }
}